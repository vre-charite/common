from common.api import module_api

api_service_utility = module_api.namespace(
    'Service utility', description='API for utility services', path='/v1/utility')